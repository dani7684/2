# Sistema de Eventos Console

## Como compilar e executar

```bash
cd eventos-console
javac src/EventConsoleApp.java
java -cp src EventConsoleApp
```

Os eventos serão salvos automaticamente em `data/events.data`.
