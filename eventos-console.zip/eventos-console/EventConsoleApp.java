// EventConsoleApp.java
// Console OOP app for managing city events with persistence in events.data
// Java 11+
// Author: ChatGPT

import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

// ======== Domain ========
enum Categoria {
    FESTA, ESPORTE, SHOW, TEATRO, CONFERENCIA, FEIRA, RELIGIOSO, OUTRO;
    public static void listar() {
        int i = 1;
        for (Categoria c : values()) {
            System.out.printf("%d) %s%n", i++, c.name());
        }
    }
    public static Categoria fromIndex(int idx) {
        if (idx < 1 || idx > values().length) throw new IllegalArgumentException("Índice inválido");
        return values()[idx - 1];
    }
}

class Usuario {
    private final String id;
    private String nome;
    private String email;
    private String cidade;

    public Usuario(String id, String nome, String email, String cidade) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.cidade = cidade;
    }

    public static Usuario criarNovo(Scanner in) {
        System.out.print("Nome: ");
        String nome = in.nextLine().trim();
        System.out.print("Email: ");
        String email = in.nextLine().trim();
        System.out.print("Cidade: ");
        String cidade = in.nextLine().trim();
        return new Usuario(UUID.randomUUID().toString(), nome, email, cidade);
    }

    public String getId() { return id; }
    public String getNome() { return nome; }
    public String getEmail() { return email; }
    public String getCidade() { return cidade; }

    @Override
    public String toString() {
        return String.format("%s (%s) - %s", nome, email, cidade);
    }
}

class Evento {
    private final String id;
    private String nome;
    private String endereco;
    private Categoria categoria;
    private LocalDateTime inicio;
    private LocalDateTime fim;
    private String descricao;
    private final Set<String> participantes; // guarda IDs de usuário

    public Evento(String id, String nome, String endereco, Categoria categoria,
                  LocalDateTime inicio, LocalDateTime fim, String descricao, Set<String> participantes) {
        this.id = id;
        this.nome = nome;
        this.endereco = endereco;
        this.categoria = categoria;
        this.inicio = inicio;
        this.fim = fim;
        this.descricao = descricao;
        this.participantes = new HashSet<>(participantes == null ? Set.of() : participantes);
    }

    public String getId() { return id; }
    public String getNome() { return nome; }
    public String getEndereco() { return endereco; }
    public Categoria getCategoria() { return categoria; }
    public LocalDateTime getInicio() { return inicio; }
    public LocalDateTime getFim() { return fim; }
    public String getDescricao() { return descricao; }
    public Set<String> getParticipantes() { return participantes; }

    public boolean estaOcorrendoAgora(Clock clock) {
        LocalDateTime agora = LocalDateTime.now(clock);
        return (agora.isEqual(inicio) || agora.isAfter(inicio)) && agora.isBefore(fim);
    }

    public boolean jaAconteceu(Clock clock) {
        return LocalDateTime.now(clock).isAfter(fim);
    }

    public long minutosAteInicio(Clock clock) {
        LocalDateTime agora = LocalDateTime.now(clock);
        return Duration.between(agora, inicio).toMinutes();
    }

    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return String.format("[%s] %s | %s | %s -> %s | %s",
                categoria, nome, endereco, inicio.format(fmt), fim.format(fmt), descricao);
    }
}

// ======== Persistence (events.data) ========
class EventoRepository {
    private final Path arquivo;
    private final DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public EventoRepository(Path arquivo) {
        this.arquivo = arquivo;
    }

    public List<Evento> carregar() {
        List<Evento> eventos = new ArrayList<>();
        if (!Files.exists(arquivo)) return eventos;
        try (BufferedReader br = Files.newBufferedReader(arquivo)) {
            String linha;
            while ((linha = br.readLine()) != null) {
                if (linha.isBlank() || linha.startsWith("#")) continue;
                // Formato pipe-delimited:
                // id|nome|endereco|categoria|inicio|fim|descricao|participantesCommaSep
                String[] p = linha.split("\\|", -1);
                if (p.length < 8) continue;
                String id = p[0];
                String nome = unescape(p[1]);
                String endereco = unescape(p[2]);
                Categoria cat = Categoria.valueOf(p[3]);
                LocalDateTime ini = LocalDateTime.parse(p[4], fmt);
                LocalDateTime fim = LocalDateTime.parse(p[5], fmt);
                String desc = unescape(p[6]);
                Set<String> participantes = new HashSet<>();
                if (!p[7].isBlank()) {
                    participantes.addAll(Arrays.asList(p[7].split(",")));
                }
                eventos.add(new Evento(id, nome, endereco, cat, ini, fim, desc, participantes));
            }
        } catch (IOException | RuntimeException ex) {
            System.err.println("Falha ao carregar events.data: " + ex.getMessage());
        }
        return eventos;
    }

    public void salvar(List<Evento> eventos) {
        try {
            if (!Files.exists(arquivo.getParent())) {
                Files.createDirectories(arquivo.getParent());
            }
            try (BufferedWriter bw = Files.newBufferedWriter(arquivo)) {
                bw.write("# events.data - não edite manualmente se não souber o formato\n");
                DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
                for (Evento e : eventos) {
                    String participantes = String.join(",", e.getParticipantes());
                    String linha = String.join("|",
                        e.getId(),
                        escape(e.getNome()),
                        escape(e.getEndereco()),
                        e.getCategoria().name(),
                        e.getInicio().format(fmt),
                        e.getFim().format(fmt),
                        escape(e.getDescricao()),
                        participantes
                    );
                    bw.write(linha);
                    bw.newLine();
                }
            }
        } catch (IOException ex) {
            System.err.println("Falha ao salvar events.data: " + ex.getMessage());
        }
    }

    private static String escape(String s) { return s.replace("|", "/"); }
    private static String unescape(String s) { return s.replace("/", "|"); }
}

// ======== Service ========
class EventoService {
    private final List<Evento> eventos;
    private final EventoRepository repo;
    private final Clock clock;

    public EventoService(EventoRepository repo, Clock clock) {
        this.repo = repo;
        this.clock = clock;
        this.eventos = new ArrayList<>(repo.carregar());
    }

    public List<Evento> listarTodosOrdenadosPorProximidade() {
        List<Evento> copia = new ArrayList<>(eventos);
        copia.sort(Comparator.comparingLong(e -> Math.abs(e.minutosAteInicio(clock))));
        return copia;
    }

    public List<Evento> listarOcorrendoAgora() {
        List<Evento> out = new ArrayList<>();
        for (Evento e : eventos) if (e.estaOcorrendoAgora(clock)) out.add(e);
        out.sort(Comparator.comparing(Evento::getInicio));
        return out;
    }

    public List<Evento> listarPassados() {
        List<Evento> out = new ArrayList<>();
        for (Evento e : eventos) if (e.jaAconteceu(clock)) out.add(e);
        out.sort(Comparator.comparing(Evento::getInicio));
        return out;
    }

    public Optional<Evento> obterPorIndice(List<Evento> lista, int indiceBase1) {
        int idx = indiceBase1 - 1;
        if (idx < 0 || idx >= lista.size()) return Optional.empty();
        return Optional.of(lista.get(idx));
    }

    public void participar(Evento evento, Usuario usuario) {
        evento.getParticipantes().add(usuario.getId());
        repo.salvar(eventos);
    }

    public void cancelar(Evento evento, Usuario usuario) {
        evento.getParticipantes().remove(usuario.getId());
        repo.salvar(eventos);
    }

    public List<Evento> listarConfirmados(Usuario usuario) {
        List<Evento> out = new ArrayList<>();
        for (Evento e : eventos) if (e.getParticipantes().contains(usuario.getId())) out.add(e);
        out.sort(Comparator.comparing(Evento::getInicio));
        return out;
    }

    public void criarEvento(Scanner in) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        System.out.print("Nome: ");
        String nome = in.nextLine().trim();
        System.out.print("Endereço: ");
        String endereco = in.nextLine().trim();
        System.out.println("Categoria:");
        Categoria.listar();
        Categoria categoria;
        while (true) {
            System.out.print("Escolha (número): ");
            String s = in.nextLine().trim();
            try {
                categoria = Categoria.fromIndex(Integer.parseInt(s));
                break;
            } catch (Exception ex) {
                System.out.println("Valor inválido. Tente novamente.");
            }
        }
        LocalDateTime inicio = null, fim = null;
        while (inicio == null) {
            System.out.print("Início (dd/MM/yyyy HH:mm): ");
            String s = in.nextLine().trim();
            try {
                inicio = LocalDateTime.parse(s, fmt);
            } catch (DateTimeParseException ex) {
                System.out.println("Formato inválido.");
            }
        }
        while (fim == null) {
            System.out.print("Fim (dd/MM/yyyy HH:mm): ");
            String s = in.nextLine().trim();
            try {
                fim = LocalDateTime.parse(s, fmt);
                if (fim.isBefore(inicio)) {
                    System.out.println("Fim não pode ser antes do início.");
                    fim = null;
                }
            } catch (DateTimeParseException ex) {
                System.out.println("Formato inválido.");
            }
        }
        System.out.print("Descrição: ");
        String descricao = in.nextLine().trim();

        Evento e = new Evento(UUID.randomUUID().toString(), nome, endereco, categoria, inicio, fim, descricao, Set.of());
        eventos.add(e);
        repo.salvar(eventos);
        System.out.println("Evento criado com sucesso!");
    }
}

// ======== Console UI (MVC - View/Controller) ========
public class EventConsoleApp {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public static void main(String[] args) {
        Locale.setDefault(new Locale("pt", "BR"));
        ZoneId tz = ZoneId.systemDefault();
        Clock clock = Clock.system(tz);

        Path dados = Paths.get("events.data");
        EventoRepository repo = new EventoRepository(dados);
        EventoService service = new EventoService(repo, clock);

        Scanner in = new Scanner(System.in);
        System.out.println("=== Sistema de Eventos (Console) ===");
        System.out.println("Cadastre seu usuário:");
        Usuario usuario = Usuario.criarNovo(in);

        while (true) {
            System.out.println("\n--- Menu ---");
            System.out.println("1) Listar eventos (ordenados por proximidade)");
            System.out.println("2) Eventos ocorrendo agora");
            System.out.println("3) Eventos já ocorridos");
            System.out.println("4) Cadastrar novo evento");
            System.out.println("5) Participar de um evento");
            System.out.println("6) Ver meus eventos confirmados");
            System.out.println("7) Cancelar participação");
            System.out.println("0) Sair");
            System.out.print("Escolha: ");
            String op = in.nextLine().trim();

            switch (op) {
                case "1":
                    listarEventos(service.listarTodosOrdenadosPorProximidade(), clock);
                    break;
                case "2":
                    listarEventos(service.listarOcorrendoAgora(), clock);
                    break;
                case "3":
                    listarEventos(service.listarPassados(), clock);
                    break;
                case "4":
                    service.criarEvento(in);
                    break;
                case "5":
                    participarEmEvento(in, service, usuario);
                    break;
                case "6":
                    List<Evento> meus = service.listarConfirmados(usuario);
                    if (meus.isEmpty()) System.out.println("Você ainda não confirmou presença em eventos.");
                    else listarEventos(meus, clock);
                    break;
                case "7":
                    cancelarParticipacao(in, service, usuario);
                    break;
                case "0":
                    System.out.println("Até logo!");
                    return;
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }

    private static void listarEventos(List<Evento> lista, Clock clock) {
        if (lista.isEmpty()) {
            System.out.println("Nenhum evento encontrado.");
            return;
        }
        int i = 1;
        for (Evento e : lista) {
            String status;
            if (e.estaOcorrendoAgora(clock)) status = "OCORRENDO AGORA";
            else if (e.jaAconteceu(clock)) status = "JÁ ACONTECEU";
            else {
                long min = e.minutosAteInicio(clock);
                if (min >= 0) status = "Começa em " + min + " min";
                else status = "Começou há " + Math.abs(min) + " min (ainda não acabou)";
            }
            System.out.printf("%d) %s%n    Endereço: %s%n    Quando: %s -> %s%n    Categoria: %s%n    Descrição: %s%n    Participantes: %d%n    Status: %s%n",
                i++,
                e.getNome(),
                e.getEndereco(),
                e.getInicio().format(FMT),
                e.getFim().format(FMT),
                e.getCategoria(),
                e.getDescricao(),
                e.getParticipantes().size(),
                status
            );
        }
    }

    private static void participarEmEvento(Scanner in, EventoService service, Usuario usuario) {
        List<Evento> lista = service.listarTodosOrdenadosPorProximidade();
        if (lista.isEmpty()) {
            System.out.println("Não há eventos para participar.");
            return;
        }
        listarEventos(lista, service == null ? Clock.systemDefaultZone() : Clock.systemDefaultZone());
        System.out.print("Informe o número do evento: ");
        try {
            int idx = Integer.parseInt(in.nextLine().trim());
            Optional<Evento> opt = service.obterPorIndice(lista, idx);
            if (opt.isPresent()) {
                service.participar(opt.get(), usuario);
                System.out.println("Participação confirmada!");
            } else {
                System.out.println("Índice inválido.");
            }
        } catch (NumberFormatException ex) {
            System.out.println("Entrada inválida.");
        }
    }

    private static void cancelarParticipacao(Scanner in, EventoService service, Usuario usuario) {
        List<Evento> lista = service.listarConfirmados(usuario);
        if (lista.isEmpty()) {
            System.out.println("Você não possui eventos confirmados.");
            return;
        }
        listarEventos(lista, service == null ? Clock.systemDefaultZone() : Clock.systemDefaultZone());
        System.out.print("Informe o número do evento para cancelar: ");
        try {
            int idx = Integer.parseInt(in.nextLine().trim());
            Optional<Evento> opt = service.obterPorIndice(lista, idx);
            if (opt.isPresent()) {
                service.cancelar(opt.get(), usuario);
                System.out.println("Participação cancelada.");
            } else {
                System.out.println("Índice inválido.");
            }
        } catch (NumberFormatException ex) {
            System.out.println("Entrada inválida.");
        }
    }
}
