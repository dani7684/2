
import java.io.*;
import java.util.*;
import java.time.*;

public class EventConsoleApp {
    static class Usuario {
        String nome;
        String email;
        String cidade;

        Usuario(String nome, String email, String cidade) {
            this.nome = nome;
            this.email = email;
            this.cidade = cidade;
        }
    }

    static class Evento {
        String nome;
        String endereco;
        String categoria;
        LocalDateTime horario;
        String descricao;
        boolean participando;

        Evento(String nome, String endereco, String categoria, LocalDateTime horario, String descricao) {
            this.nome = nome;
            this.endereco = endereco;
            this.categoria = categoria;
            this.horario = horario;
            this.descricao = descricao;
            this.participando = false;
        }

        @Override
        public String toString() {
            return nome + " | " + categoria + " | " + endereco + " | " + horario + " | " + descricao + 
                   (participando ? " [Participando]" : "");
        }
    }

    static List<Evento> eventos = new ArrayList<>();
    static final String FILE_PATH = "data/events.data";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        carregarEventos();

        System.out.println("=== Sistema de Eventos ===");
        System.out.print("Digite seu nome: ");
        String nome = sc.nextLine();
        System.out.print("Digite seu email: ");
        String email = sc.nextLine();
        System.out.print("Digite sua cidade: ");
        String cidade = sc.nextLine();
        Usuario usuario = new Usuario(nome, email, cidade);

        int opcao;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Listar eventos");
            System.out.println("2. Cadastrar evento");
            System.out.println("3. Participar de evento");
            System.out.println("4. Cancelar participação");
            System.out.println("5. Salvar e sair");
            System.out.print("Escolha: ");
            opcao = Integer.parseInt(sc.nextLine());

            switch(opcao) {
                case 1: listarEventos(); break;
                case 2: cadastrarEvento(sc); break;
                case 3: participarEvento(sc); break;
                case 4: cancelarParticipacao(sc); break;
                case 5: salvarEventos(); System.out.println("Saindo..."); break;
                default: System.out.println("Opção inválida");
            }
        } while(opcao != 5);

        sc.close();
    }

    static void listarEventos() {
        if (eventos.isEmpty()) {
            System.out.println("Nenhum evento cadastrado.");
            return;
        }
        eventos.sort(Comparator.comparing(e -> e.horario));
        for (int i = 0; i < eventos.size(); i++) {
            System.out.println(i + ". " + eventos.get(i));
        }
    }

    static void cadastrarEvento(Scanner sc) {
        System.out.print("Nome do evento: ");
        String nome = sc.nextLine();
        System.out.print("Endereço: ");
        String endereco = sc.nextLine();
        System.out.print("Categoria (Show, Festa, Esporte, etc.): ");
        String categoria = sc.nextLine();
        System.out.print("Data e hora (yyyy-MM-ddTHH:mm): ");
        LocalDateTime horario = LocalDateTime.parse(sc.nextLine());
        System.out.print("Descrição: ");
        String descricao = sc.nextLine();

        eventos.add(new Evento(nome, endereco, categoria, horario, descricao));
        System.out.println("Evento cadastrado!");
    }

    static void participarEvento(Scanner sc) {
        listarEventos();
        System.out.print("Digite o número do evento para participar: ");
        int idx = Integer.parseInt(sc.nextLine());
        if (idx >= 0 && idx < eventos.size()) {
            eventos.get(idx).participando = true;
            System.out.println("Participação confirmada!");
        } else {
            System.out.println("Evento inválido.");
        }
    }

    static void cancelarParticipacao(Scanner sc) {
        listarEventos();
        System.out.print("Digite o número do evento para cancelar: ");
        int idx = Integer.parseInt(sc.nextLine());
        if (idx >= 0 && idx < eventos.size() && eventos.get(idx).participando) {
            eventos.get(idx).participando = false;
            System.out.println("Participação cancelada!");
        } else {
            System.out.println("Evento inválido ou não está participando.");
        }
    }

    static void salvarEventos() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Evento e : eventos) {
                bw.write(e.nome + ";" + e.endereco + ";" + e.categoria + ";" + e.horario + ";" + e.descricao + ";" + e.participando);
                bw.newLine();
            }
            System.out.println("Eventos salvos com sucesso!");
        } catch (IOException ex) {
            System.out.println("Erro ao salvar eventos: " + ex.getMessage());
        }
    }

    static void carregarEventos() {
        File file = new File(FILE_PATH);
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 6) {
                    Evento e = new Evento(parts[0], parts[1], parts[2], LocalDateTime.parse(parts[3]), parts[4]);
                    e.participando = Boolean.parseBoolean(parts[5]);
                    eventos.add(e);
                }
            }
            System.out.println("Eventos carregados!");
        } catch (IOException ex) {
            System.out.println("Erro ao carregar eventos: " + ex.getMessage());
        }
    }
}
